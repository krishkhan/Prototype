// EDF_CHECK.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Judge.h"


int _tmain(int argc, _TCHAR* argv[])
{
	if (argc <= 1)
	{
		return -1;
	}
	CJudge *cj = new CJudge();
	int r = cj->check(argv[1]);
	switch (r)
	{
		case -1:
			fprintf(stderr, "ERROR\n");
			break;
		case 0:
			fprintf(stderr, "NO DATA\n");
			break;
		case 1:
			fprintf(stderr, "This file has one or more drawing block(s)\n");
			break;
		case 2:
			fprintf(stderr, "This file has a sheet name\n");
			break;
		case 3:
			fprintf(stderr, "This file has a sheet comment\n");
			break;
	}
#ifdef DEBUG
	fprintf(stderr, "%s\n", cj->Message());
#endif
	delete cj;
	
	return 0;
}

