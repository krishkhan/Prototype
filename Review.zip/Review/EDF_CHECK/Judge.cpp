#include "StdAfx.h"
#include "Judge.h"
#include <sys/stat.h>
#include "yGet_EDF_File.h"

CJudge::CJudge(void)
{
	m_fin = NULL;
#ifdef DEBUG
	memset(m_message, 0, sizeof(m_message));
#endif
}

CJudge::~CJudge(void)
{
	if (m_fin)
	{
		delete m_fin;
	}
}

#ifdef DEBUG
	const char *CJudge::Message()
	{
		return m_message;
	}
#endif

bool CJudge::readContents()
{
	memset(&m_contents, 0, sizeof(m_contents));
	if (!m_fin->read((char *)&m_contents, sizeof(m_contents)))
	{
		return false;
	}
	return true;
}

bool CJudge::check_RGTL()
{
#ifdef DEBUG
	memset(m_message, 0, sizeof(m_message));
	sprintf(m_message, "Drawing number = %d", m_contents.Number);
#endif
	return (0 < m_contents.Number);
}

bool CJudge::check_EDWK()
{
	if (m_contents.Offset <= 0 || m_contents.Pitch <= 0)
	{
		return false;
	}

	int pos = m_fin->tellg();
	char *buff = new char [m_contents.Pitch];
	bool r = false;
	for (;;)
	{
		m_fin->seekg(m_contents.Offset);
		if (!m_fin->read(buff, m_contents.Pitch))
		{
			break;
		}
		if (memcmp(buff, "MXDB:", 5) == 0)
		{
			char *p = strstr(buff, "ST:");
			char *q = strrchr(buff, ';');
			if ((p != NULL) && (q != NULL))
			{
				p += (sizeof("ST:") - 1);
				int len = (q - p);
				r = (0 < len);
#ifdef DEBUG
				if (r)
				{
					memset(m_message, 0, sizeof(m_message));
					strncpy(m_message, p, len);
				}
#endif
			}
		}
		break;
	}
	delete [] buff;
	m_fin->seekg(pos);
	return r;
}

bool CJudge::check_BKCM()
{
	if (m_contents.Offset <= 0 || m_contents.Pitch <= 0)
	{
		return false;
	}

	int pos = m_fin->tellg();
	char *buff = new char [m_contents.Pitch];
	bool r = false;
	for (;;)
	{
		m_fin->seekg(m_contents.Offset);
		if (!m_fin->read(buff, m_contents.Pitch))
		{
			break;
		}
		r = (0 < strlen(buff));
#ifdef DEBUG
		if (r)
		{
			memset(m_message, 0, sizeof(m_message));
			strncpy(m_message, buff, sizeof(m_message)-1);
		}
#endif
		break;
	}
	delete [] buff;
	m_fin->seekg(pos);
	return r;
}


int CJudge::check(const wchar_t *path)
{
	struct _stat64i32 stbuf;
	if (_wstat(path, &stbuf) != 0)
	{
		return -1;
	}
	size_t fileSize = stbuf.st_size;
	if (fileSize < 0)
	{
		return -1;
	}

	m_fin = new ifstream( path, ios::in | ios::binary );
	if (!m_fin)
	{
		return -1;
	}
	_edf_header_ header;
	memset(&header, 0, sizeof(header));
	int rtn = -1;

	for (;;)
	{
		if (!m_fin->read((char *)&header, sizeof(header)))
		{
			break;
		}
		if (memcmp(header.FileName, _EDF_FILENAME, sizeof(_EDF_FILENAME)) != 0)
		{
			break;
		}
		if (header.EditorID != _EDF_EDITORID)
		{
			break;
		}
		if (header.FileType[0] != 'L' || header.FileType[4] != 'B')
		{
			break;
		}

		bool rgtl = true;
		bool edwk = true;
		bool bkcm = true;
		for (int i=0; (i<=27) && (rtn < 0); i++)
		{
			if ((rgtl == false) && (edwk == false) && (bkcm == false))
			{
				break;
			}

			if (readContents() == false)
			{
				break;
			}
			
			/*if (rgtl)
			{
				if (memcmp(m_contents.item, "RGTL", 4) == 0)
				{
					rgtl = false;
					if (check_RGTL())
					{
						rtn = 1;
						break;
					}
				}
			}*/

			if (edwk)
			{
				if (memcmp(m_contents.item, "EDWK", 4) == 0)
				{
					edwk = false;
					if (check_EDWK())
					{
						rtn = 2;
						break;
					}
				} else {
					int a = 0;
				}
			}

			if (bkcm)
			{
				if (memcmp(m_contents.item, "BKCM", 4) == 0)
				{
					bkcm = false;
					if (check_BKCM())
					{
						rtn = 3;
						break;
					}
				}
			}
		}

		if (rtn < 0)
		{
			rtn = 0;
		}
		break;
	}
	
	m_fin->close(); 
	delete m_fin;
	m_fin = NULL;
	return rtn;
}
