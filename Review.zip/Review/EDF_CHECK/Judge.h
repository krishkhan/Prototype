#pragma once

#include <iostream>
#include <fstream>
#include "yGet_EDF_File.h"
using namespace std;

#define	_EDF_FILENAME	"FCDRW"
#define	_EDF_EDITORID	0x2126

class CJudge
{
private:
	bool readContents();
	bool check_RGTL();
	bool check_EDWK();
	bool check_BKCM();
	_edf_contents	m_contents;
	ifstream *m_fin;
#ifdef DEBUG
	char m_message[100];
#endif
public:
	CJudge(void);
	~CJudge(void);
	int check(const wchar_t *);
#ifdef DEBUG
	const char *Message();
#endif
};
