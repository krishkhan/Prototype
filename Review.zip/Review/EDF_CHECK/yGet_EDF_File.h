#pragma once

typedef unsigned long U32;

typedef struct edf_header_
{
	char FileName[12];
	U32	EditorID;
	char ProName[8];
	char HostName[8];
	char dummy[12];
	U32	ItemNumber;
	U32	CreateTime;
	U32	ModifyTime;
	char FileType[8];
} _edf_header_;

typedef struct edf_contents_
{
	char item[4];
	U32	Offset;
	U32	Number;
	U32	Pitch;
} _edf_contents;

typedef struct _edf_file_
{
	_edf_header_	header;
	_edf_contents	contents[27];
} _edf_file_;

